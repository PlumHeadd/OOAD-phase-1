package com.example.demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.entity.HealthData;

public interface HealthDataRepository extends JpaRepository<HealthData, Long> { }
